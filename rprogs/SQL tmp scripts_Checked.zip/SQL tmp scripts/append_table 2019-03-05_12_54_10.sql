INSERT INTO [IDI_Sandpit].[DL-MAA2016-15].chh_replaced_notifications("snz_uid", "notification_date", "address_uid", "source", "validation", "replaced")
  SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "replaced"
FROM (SELECT "snz_uid", "address_uid", "notification_date", "source", "validation", "concurrent_flag", 'standardise move in date' AS "replaced"
FROM (SELECT DISTINCT *
FROM (SELECT "snz_uid", "address_uid", "notification_date", "source", "validation", "concurrent_flag"
FROM [IDI_Sandpit].[DL-MAA2016-15].chh_tmp_records_to_change) "uaprtpeant") "rfvarahtfq") "uquscljexl"
