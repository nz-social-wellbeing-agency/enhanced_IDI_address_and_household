SELECT *
INTO [IDI_Sandpit].[DL-MAA2016-15]."chh_accuracy_coded"
FROM (
SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "accuracy"
FROM (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "accuracy"
FROM (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "accuracy"
FROM (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "birth_date", "age_at_notice", "censored_age_step", "censored_age_at_notice", "num_match", "num", "accuracy_ratio_detailed", "accuracy_ratio_coarse", CASE WHEN ((CONVERT(BIT, IIF("accuracy_ratio_detailed" IS NULL, 1, 0))) =  'TRUE') THEN ("accuracy_ratio_coarse") WHEN ((CONVERT(BIT, IIF("accuracy_ratio_detailed" IS NULL, 1, 0))) =  'FALSE') THEN ("accuracy_ratio_detailed") END AS "accuracy"
FROM (SELECT "TBL_LEFT"."snz_uid" AS "snz_uid", "TBL_LEFT"."notification_date" AS "notification_date", "TBL_LEFT"."address_uid" AS "address_uid", "TBL_LEFT"."source" AS "source", "TBL_LEFT"."validation" AS "validation", "TBL_LEFT"."birth_date" AS "birth_date", "TBL_LEFT"."age_at_notice" AS "age_at_notice", "TBL_LEFT"."censored_age_step" AS "censored_age_step", "TBL_LEFT"."censored_age_at_notice" AS "censored_age_at_notice", "TBL_LEFT"."num_match" AS "num_match", "TBL_LEFT"."num" AS "num", "TBL_LEFT"."accuracy_ratio_detailed" AS "accuracy_ratio_detailed", "TBL_RIGHT"."accuracy_ratio_coarse" AS "accuracy_ratio_coarse"
  FROM (SELECT "TBL_LEFT"."snz_uid" AS "snz_uid", "TBL_LEFT"."notification_date" AS "notification_date", "TBL_LEFT"."address_uid" AS "address_uid", "TBL_LEFT"."source" AS "source", "TBL_LEFT"."validation" AS "validation", "TBL_LEFT"."birth_date" AS "birth_date", "TBL_LEFT"."age_at_notice" AS "age_at_notice", "TBL_LEFT"."censored_age_step" AS "censored_age_step", "TBL_LEFT"."censored_age_at_notice" AS "censored_age_at_notice", "TBL_RIGHT"."num_match" AS "num_match", "TBL_RIGHT"."num" AS "num", "TBL_RIGHT"."accuracy_ratio_detailed" AS "accuracy_ratio_detailed"
  FROM (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "birth_date", "age_at_notice", "censored_age_step", CASE WHEN ((CONVERT(BIT, IIF("censored_age_step" <= 1.0, 1.0, 0.0))) =  'TRUE') THEN (1.0) WHEN ((CONVERT(BIT, IIF("censored_age_step" <= 1.0, 1.0, 0.0))) =  'FALSE') THEN ("censored_age_step") END AS "censored_age_at_notice"
FROM (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "birth_date", "age_at_notice", CASE WHEN ((CONVERT(BIT, IIF("age_at_notice" >= 90.0, 1.0, 0.0))) =  'TRUE') THEN (90.0) WHEN ((CONVERT(BIT, IIF("age_at_notice" >= 90.0, 1.0, 0.0))) =  'FALSE') THEN ("age_at_notice") END AS "censored_age_step"
FROM (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "birth_date", DATEDIFF("YEAR", "birth_date", "notification_date") AS "age_at_notice"
FROM (SELECT "TBL_LEFT"."snz_uid" AS "snz_uid", "TBL_LEFT"."notification_date" AS "notification_date", "TBL_LEFT"."address_uid" AS "address_uid", "TBL_LEFT"."source" AS "source", "TBL_LEFT"."validation" AS "validation", "TBL_RIGHT"."birth_date" AS "birth_date"
  FROM (SELECT *
FROM [IDI_Sandpit].[DL-MAA2016-15].chh_tmp_cautious_9883880848
WHERE ("validation" = 'NO')) "TBL_LEFT"
  INNER JOIN (SELECT "snz_uid", "birth_date"
FROM (SELECT "link_set_key", "snz_uid", "snz_sex_code", "snz_birth_year_nbr", "snz_birth_month_nbr", "snz_ethnicity_grp1_nbr", "snz_ethnicity_grp2_nbr", "snz_ethnicity_grp3_nbr", "snz_ethnicity_grp4_nbr", "snz_ethnicity_grp5_nbr", "snz_ethnicity_grp6_nbr", "snz_deceased_year_nbr", "snz_deceased_month_nbr", "snz_parent1_uid", "snz_parent2_uid", "snz_person_ind", "snz_spine_ind", "snz_ethnicity_source_code", DATEFROMPARTS("snz_birth_year_nbr", "snz_birth_month_nbr", 15.0) AS "birth_date"
FROM (SELECT *
FROM [IDI_Clean_20181020].[data].personal_detail
WHERE ("snz_uid" % 100.0 = 0.0)) "uitgrugcew") "umbzwmlyoe") "TBL_RIGHT"
  ON ("TBL_LEFT"."snz_uid" = "TBL_RIGHT"."snz_uid")
) "thesdkijri") "wrylwkoqsw") "abtbbybmac") "TBL_LEFT"
  LEFT JOIN (SELECT "source_to_validate", "censored_age_at_notice", "num_match", "num", 1.0 * "num_match" / "num" AS "accuracy_ratio_detailed"
FROM [IDI_Sandpit].[DL-MAA2016-15].chh_tmp_accuracy_matches_and_count) "TBL_RIGHT"
  ON ("TBL_LEFT"."source" = "TBL_RIGHT"."source_to_validate" AND "TBL_LEFT"."censored_age_at_notice" = "TBL_RIGHT"."censored_age_at_notice")
) "TBL_LEFT"
  LEFT JOIN (SELECT "source_to_validate", 1.0 * SUM("num_match") / SUM("num") AS "accuracy_ratio_coarse"
FROM [IDI_Sandpit].[DL-MAA2016-15].chh_tmp_accuracy_matches_and_count
GROUP BY "source_to_validate") "TBL_RIGHT"
  ON ("TBL_LEFT"."source" = "TBL_RIGHT"."source_to_validate")
) "qlhsyzbqik") "dunrrhcxyv") "ygizevmvoh"
UNION ALL
SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "accuracy"
FROM (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "accuracy"
FROM (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", 1.0 AS "accuracy"
FROM (SELECT *
FROM [IDI_Sandpit].[DL-MAA2016-15].chh_tmp_cautious_9883880848
WHERE ("validation" = 'YES')) "xjdwvekmim") "srbnisdibs") "gjhqtswjrf") "vkctmmaldt"
) "long1390787"
