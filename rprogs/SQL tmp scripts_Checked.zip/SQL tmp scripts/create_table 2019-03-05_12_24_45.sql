CREATE TABLE [IDI_Sandpit].[DL-MAA2016-15].chh_individual_refined(
[snz_uid] [int] NOT NULL,
[notification_date] [date] NOT NULL,
[address_uid] [int] NOT NULL,
[source] [varchar](25) NULL,
[validation] [varchar](3) NOT NULL,
[concurrent_flag] [int] NOT NULL
) ON [PRIMARY]
