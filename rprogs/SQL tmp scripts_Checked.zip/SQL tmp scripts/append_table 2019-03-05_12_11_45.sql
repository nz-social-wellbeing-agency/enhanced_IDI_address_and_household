INSERT INTO [IDI_Sandpit].[DL-MAA2016-15].chh_gathered_data("snz_uid", "notification_date", "address_uid", "source", "validation")
  SELECT "snz_uid", "notification_date", "address_uid", "source", "validation"
FROM [IDI_UserCode].[DL-MAA2016-15].chh_census_prev_notifications
