IF OBJECT_ID('[IDI_Sandpit].[DL-MAA2016-15]."chh_tmp_cautious_9883880848"','U') IS NOT NULL 
DROP TABLE [IDI_Sandpit].[DL-MAA2016-15]."chh_tmp_cautious_9883880848";
