IF OBJECT_ID('[IDI_Sandpit].[DL-MAA2016-15]."chh_tmp_consistent_moves_9734870898"','U') IS NOT NULL 
DROP TABLE [IDI_Sandpit].[DL-MAA2016-15]."chh_tmp_consistent_moves_9734870898";
