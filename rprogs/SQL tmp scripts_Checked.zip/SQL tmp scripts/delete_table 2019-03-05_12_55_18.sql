IF OBJECT_ID('[IDI_Sandpit].[DL-MAA2016-15]."chh_tmp_sync_child_3"','U') IS NOT NULL 
DROP TABLE [IDI_Sandpit].[DL-MAA2016-15]."chh_tmp_sync_child_3";
