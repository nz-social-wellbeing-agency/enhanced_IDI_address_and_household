INSERT INTO [IDI_Sandpit].[DL-MAA2016-15].chh_replaced_notifications("snz_uid", "notification_date", "address_uid", "source", "validation", "replaced")
  SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "replaced"
FROM (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", 'lower quality' AS "replaced"
FROM (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation"
FROM (SELECT *
FROM [IDI_Sandpit].[DL-MAA2016-15].chh_tmp_quality_iteration_3
WHERE ("high_quality" = 0.0 AND "validation" = 'NO')) "nrnfacmjpz") "mceznwypwa") "jijojarpkh"
