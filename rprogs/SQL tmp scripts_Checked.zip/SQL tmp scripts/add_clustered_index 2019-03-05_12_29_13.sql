CREATE CLUSTERED INDEX my_clustered_index ON [IDI_Sandpit].[DL-MAA2016-15].chh_tmp_quality_iteration_0 ( [snz_uid], [notification_date] )
