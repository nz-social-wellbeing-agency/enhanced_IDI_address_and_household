INSERT INTO [IDI_Sandpit].[DL-MAA2016-15].chh_household_validation("snz_uid", "notification_date", "address_uid", "household_uid", "source")
  SELECT "snz_uid", "notification_date", "address_uid", "household_uid", "source"
FROM [IDI_UserCode].[DL-MAA2016-15].chh_census_validation
