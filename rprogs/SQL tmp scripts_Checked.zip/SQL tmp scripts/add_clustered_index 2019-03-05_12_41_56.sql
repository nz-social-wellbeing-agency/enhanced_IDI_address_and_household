CREATE CLUSTERED INDEX my_clustered_index ON [IDI_Sandpit].[DL-MAA2016-15].chh_tmp_full_address_moves ( [address_uid], [prev_address_uid] )
