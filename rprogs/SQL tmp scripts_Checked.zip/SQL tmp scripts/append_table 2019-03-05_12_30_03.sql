INSERT INTO [IDI_Sandpit].[DL-MAA2016-15].chh_replaced_notifications("snz_uid", "notification_date", "address_uid", "source", "validation", "replaced")
  SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "replaced"
FROM [IDI_Sandpit].[DL-MAA2016-15].chh_tmp_last_unsupported_simultaneous_notifications
