INSERT INTO [IDI_Sandpit].[DL-MAA2016-15].chh_replaced_notifications("snz_uid", "notification_date", "address_uid", "source", "validation", "replaced")
  SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "replaced"
FROM (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "replaced"
FROM (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", CONCAT('notification is prior to ', '2001-01-01') AS "replaced"
FROM (SELECT *
FROM (SELECT *
FROM [IDI_Sandpit].[DL-MAA2016-15].chh_gathered_data
WHERE ("snz_uid" % 100.0 = 0.0)) "djuyaculnu"
WHERE ("notification_date" < '2001-01-01')) "dydcgxeegc") "pmqibjpuoz"
UNION ALL
SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "replaced"
FROM (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", CONCAT('notification is post to ', '2017-12-31') AS "replaced"
FROM (SELECT *
FROM (SELECT *
FROM [IDI_Sandpit].[DL-MAA2016-15].chh_gathered_data
WHERE ("snz_uid" % 100.0 = 0.0)) "clqjjmixug"
WHERE ('2017-12-31' < "notification_date")) "etcywystbi") "opquligyrt") "knwqlusuzy"
