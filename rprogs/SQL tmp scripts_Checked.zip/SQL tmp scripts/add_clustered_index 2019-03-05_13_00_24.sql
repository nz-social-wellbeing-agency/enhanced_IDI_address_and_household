CREATE CLUSTERED INDEX my_clustered_index ON [IDI_Sandpit].[DL-MAA2016-15].chh_tmp_consistent_moves_5551174844 ( [snz_uid] )
