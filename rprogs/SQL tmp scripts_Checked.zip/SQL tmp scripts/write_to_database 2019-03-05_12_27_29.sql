SELECT *
INTO [IDI_Sandpit].[DL-MAA2016-15]."chh_tmp_cautious_9883880848"
FROM (
SELECT *
FROM (SELECT *
FROM [IDI_Sandpit].[DL-MAA2016-15].chh_gathered_data
WHERE ("snz_uid" % 100.0 = 0.0)) "mfdhdzmfka"
WHERE ('2001-01-01' <= "notification_date" AND "notification_date" <= '2017-12-31')
) "long1493692"
