SELECT *
INTO [IDI_Sandpit].[DL-MAA2016-15]."chh_tmp_add_accuracy"
FROM (
SELECT *
FROM (SELECT "TBL_LEFT"."snz_uid" AS "snz_uid", "TBL_LEFT"."notification_date" AS "notification_date_true", "TBL_LEFT"."address_uid" AS "address_uid_true", "TBL_LEFT"."source" AS "source_true", "TBL_LEFT"."validation" AS "validation_true", "TBL_RIGHT"."notification_date" AS "notification_date_to_validate", "TBL_RIGHT"."address_uid" AS "address_uid_to_validate", "TBL_RIGHT"."source" AS "source_to_validate", "TBL_RIGHT"."validation" AS "validation_to_validate", "TBL_RIGHT"."birth_date" AS "birth_date", "TBL_RIGHT"."age_at_notice" AS "age_at_notice", "TBL_RIGHT"."censored_age_step" AS "censored_age_step", "TBL_RIGHT"."censored_age_at_notice" AS "censored_age_at_notice"
  FROM (SELECT *
FROM [IDI_Sandpit].[DL-MAA2016-15].chh_tmp_cautious_9883880848
WHERE ("validation" = 'YES')) "TBL_LEFT"
  INNER JOIN (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "birth_date", "age_at_notice", "censored_age_step", CASE WHEN ((CONVERT(BIT, IIF("censored_age_step" <= 1.0, 1.0, 0.0))) =  'TRUE') THEN (1.0) WHEN ((CONVERT(BIT, IIF("censored_age_step" <= 1.0, 1.0, 0.0))) =  'FALSE') THEN ("censored_age_step") END AS "censored_age_at_notice"
FROM (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "birth_date", "age_at_notice", CASE WHEN ((CONVERT(BIT, IIF("age_at_notice" >= 90.0, 1.0, 0.0))) =  'TRUE') THEN (90.0) WHEN ((CONVERT(BIT, IIF("age_at_notice" >= 90.0, 1.0, 0.0))) =  'FALSE') THEN ("age_at_notice") END AS "censored_age_step"
FROM (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "birth_date", DATEDIFF("YEAR", "birth_date", "notification_date") AS "age_at_notice"
FROM (SELECT "TBL_LEFT"."snz_uid" AS "snz_uid", "TBL_LEFT"."notification_date" AS "notification_date", "TBL_LEFT"."address_uid" AS "address_uid", "TBL_LEFT"."source" AS "source", "TBL_LEFT"."validation" AS "validation", "TBL_RIGHT"."birth_date" AS "birth_date"
  FROM (SELECT *
FROM [IDI_Sandpit].[DL-MAA2016-15].chh_tmp_cautious_9883880848
WHERE ("validation" = 'NO')) "TBL_LEFT"
  INNER JOIN (SELECT "snz_uid", "birth_date"
FROM (SELECT "link_set_key", "snz_uid", "snz_sex_code", "snz_birth_year_nbr", "snz_birth_month_nbr", "snz_ethnicity_grp1_nbr", "snz_ethnicity_grp2_nbr", "snz_ethnicity_grp3_nbr", "snz_ethnicity_grp4_nbr", "snz_ethnicity_grp5_nbr", "snz_ethnicity_grp6_nbr", "snz_deceased_year_nbr", "snz_deceased_month_nbr", "snz_parent1_uid", "snz_parent2_uid", "snz_person_ind", "snz_spine_ind", "snz_ethnicity_source_code", DATEFROMPARTS("snz_birth_year_nbr", "snz_birth_month_nbr", 15.0) AS "birth_date"
FROM (SELECT *
FROM [IDI_Clean_20181020].[data].personal_detail
WHERE ("snz_uid" % 100.0 = 0.0)) "hemdpkrlxv") "bulyqzevfp") "TBL_RIGHT"
  ON ("TBL_LEFT"."snz_uid" = "TBL_RIGHT"."snz_uid")
) "udkfquljpl") "tdiqzoqbnn") "iqxpuquijf") "TBL_RIGHT"
  ON ("TBL_LEFT"."snz_uid" = "TBL_RIGHT"."snz_uid")
) "mhcblryvtl"
WHERE ("notification_date_to_validate" <= "notification_date_true")
) "long5766820"
