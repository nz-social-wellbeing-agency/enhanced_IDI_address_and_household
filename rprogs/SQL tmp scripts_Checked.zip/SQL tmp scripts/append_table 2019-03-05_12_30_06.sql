INSERT INTO [IDI_Sandpit].[DL-MAA2016-15].chh_replaced_notifications("snz_uid", "notification_date", "address_uid", "source", "validation", "replaced")
  SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "replaced"
FROM (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "concurrent_flag", 'not address change' AS "replaced"
FROM (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "concurrent_flag"
FROM (SELECT *
FROM (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "accuracy", "gap_end", "need_support_before", "concurrent_flag", LAG("notification_date", 1, NULL) OVER (PARTITION BY "snz_uid" ORDER BY "notification_date") AS "lag_notification_date", LAG("address_uid", 1, NULL) OVER (PARTITION BY "snz_uid" ORDER BY "notification_date") AS "lag_address_uid", LAG("concurrent_flag", 1, NULL) OVER (PARTITION BY "snz_uid" ORDER BY "notification_date") AS "lag_concurrent_flag"
FROM [IDI_Sandpit].[DL-MAA2016-15].chh_tmp_cautious_4065634370) "gheumqeeft"
WHERE ("address_uid" = "lag_address_uid" AND "concurrent_flag" = "lag_concurrent_flag")) "bgwbcjyqzn") "xryzdpyfjq") "ynrlmznygp"
