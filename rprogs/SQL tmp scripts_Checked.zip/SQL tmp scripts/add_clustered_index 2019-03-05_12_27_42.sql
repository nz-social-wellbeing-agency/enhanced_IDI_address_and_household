CREATE CLUSTERED INDEX my_clustered_index ON [IDI_Sandpit].[DL-MAA2016-15].chh_tmp_cautious_9883880848 ( [snz_uid] )
