INSERT INTO [IDI_Sandpit].[DL-MAA2016-15].chh_address_changes("snz_uid", "notification_date", "address_uid", "source", "validation", "concurrent_flag")
  SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "concurrent_flag"
FROM (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "concurrent_flag"
FROM (SELECT *
FROM (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "accuracy", "gap_end", "need_support_before", "concurrent_flag", LAG("notification_date", 1, NULL) OVER (PARTITION BY "snz_uid" ORDER BY "notification_date") AS "lag_notification_date", LAG("address_uid", 1, NULL) OVER (PARTITION BY "snz_uid" ORDER BY "notification_date") AS "lag_address_uid", LAG("concurrent_flag", 1, NULL) OVER (PARTITION BY "snz_uid" ORDER BY "notification_date") AS "lag_concurrent_flag"
FROM [IDI_Sandpit].[DL-MAA2016-15].chh_tmp_cautious_4065634370) "bnhmojwlcz"
WHERE ((("lag_notification_date") IS NULL) OR "address_uid" != "lag_address_uid" OR "concurrent_flag" != "lag_concurrent_flag")) "bwycngilfg") "hfomgirshn"
