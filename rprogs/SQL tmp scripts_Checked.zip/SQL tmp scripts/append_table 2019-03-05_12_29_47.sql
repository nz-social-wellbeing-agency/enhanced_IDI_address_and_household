INSERT INTO [IDI_Sandpit].[DL-MAA2016-15].chh_replaced_notifications("snz_uid", "notification_date", "address_uid", "source", "validation", "replaced")
  SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "replaced"
FROM (SELECT "snz_uid", "notification_date", "address_uid", "source", "gap_end", "need_support_before", "validation", "accuracy", "birth_date", "age_at_notice", "high_quality", "next_date", "days_gap", 'in gap unsupported' AS "replaced"
FROM (SELECT *
FROM (SELECT "TBL_LEFT"."snz_uid" AS "snz_uid", "TBL_LEFT"."notification_date" AS "notification_date", "TBL_LEFT"."address_uid" AS "address_uid", "TBL_LEFT"."source" AS "source", "TBL_LEFT"."gap_end" AS "gap_end", "TBL_LEFT"."need_support_before" AS "need_support_before", "TBL_RIGHT"."validation" AS "validation", "TBL_RIGHT"."accuracy" AS "accuracy", "TBL_RIGHT"."birth_date" AS "birth_date", "TBL_RIGHT"."age_at_notice" AS "age_at_notice", "TBL_RIGHT"."high_quality" AS "high_quality", "TBL_RIGHT"."next_date" AS "next_date", "TBL_RIGHT"."days_gap" AS "days_gap"
  FROM [IDI_Sandpit].[DL-MAA2016-15].chh_tmp_notifications_in_gaps_796714997 AS "TBL_LEFT"
  INNER JOIN (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "accuracy", "birth_date", "age_at_notice", "high_quality", "next_date", DATEDIFF("DAY", "notification_date", "next_date") AS "days_gap"
FROM (SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "accuracy", "birth_date", "age_at_notice", "high_quality", LEAD("notification_date", 1.0, NULL) OVER (PARTITION BY "snz_uid", "address_uid" ORDER BY "notification_date") AS "next_date"
FROM [IDI_Sandpit].[DL-MAA2016-15].chh_tmp_cautious_461208510) "mgojxxfsaa") "TBL_RIGHT"
  ON ("TBL_LEFT"."snz_uid" = "TBL_RIGHT"."snz_uid" AND "TBL_LEFT"."notification_date" = "TBL_RIGHT"."notification_date" AND "TBL_LEFT"."address_uid" = "TBL_RIGHT"."address_uid" AND "TBL_LEFT"."source" = "TBL_RIGHT"."source")
) "stgtgjuvey"
WHERE (((("next_date") IS NULL) OR "need_support_before" < "next_date") AND "validation" = 'NO')) "nqbmhxfnzw") "pkgqfqwwqz"
