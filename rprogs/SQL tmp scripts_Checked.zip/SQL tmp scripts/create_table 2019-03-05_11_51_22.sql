CREATE TABLE [IDI_Sandpit].[DL-MAA2016-15].chh_gathered_data(
[snz_uid] [int] NOT NULL,
[notification_date] [date] NOT NULL,
[address_uid] [int] NOT NULL,
[source] [varchar](25) NULL,
[validation] [varchar](3) NOT NULL
) ON [PRIMARY]
