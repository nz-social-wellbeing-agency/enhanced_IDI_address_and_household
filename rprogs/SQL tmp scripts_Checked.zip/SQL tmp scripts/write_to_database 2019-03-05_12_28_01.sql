SELECT *
INTO [IDI_Sandpit].[DL-MAA2016-15]."chh_tmp_accuracy_matches_and_count"
FROM (
SELECT "source_to_validate", "censored_age_at_notice", SUM("match") AS "num_match", COUNT(*) AS "num"
FROM (SELECT "snz_uid", "notification_date_true", "address_uid_true", "source_true", "validation_true", "notification_date_to_validate", "address_uid_to_validate", "source_to_validate", "validation_to_validate", "birth_date", "age_at_notice", "censored_age_step", "censored_age_at_notice", CASE WHEN ((CONVERT(BIT, IIF("address_uid_to_validate" = "address_uid_true", 1.0, 0.0))) =  'TRUE') THEN (1.0) WHEN ((CONVERT(BIT, IIF("address_uid_to_validate" = "address_uid_true", 1.0, 0.0))) =  'FALSE') THEN (0.0) END AS "match"
FROM (SELECT "TBL_LEFT"."snz_uid" AS "snz_uid", "TBL_LEFT"."notification_date_true" AS "notification_date_true", "TBL_LEFT"."address_uid_true" AS "address_uid_true", "TBL_LEFT"."source_true" AS "source_true", "TBL_LEFT"."validation_true" AS "validation_true", "TBL_LEFT"."notification_date_to_validate" AS "notification_date_to_validate", "TBL_LEFT"."address_uid_to_validate" AS "address_uid_to_validate", "TBL_LEFT"."source_to_validate" AS "source_to_validate", "TBL_LEFT"."validation_to_validate" AS "validation_to_validate", "TBL_LEFT"."birth_date" AS "birth_date", "TBL_LEFT"."age_at_notice" AS "age_at_notice", "TBL_LEFT"."censored_age_step" AS "censored_age_step", "TBL_LEFT"."censored_age_at_notice" AS "censored_age_at_notice"
  FROM [IDI_Sandpit].[DL-MAA2016-15].chh_tmp_add_accuracy AS "TBL_LEFT"
  INNER JOIN (SELECT "snz_uid", "notification_date_true", "address_uid_true", "source_true", MAX("notification_date_to_validate") AS "max_date"
FROM [IDI_Sandpit].[DL-MAA2016-15].chh_tmp_add_accuracy
GROUP BY "snz_uid", "notification_date_true", "address_uid_true", "source_true") "TBL_RIGHT"
  ON ("TBL_LEFT"."snz_uid" = "TBL_RIGHT"."snz_uid" AND "TBL_LEFT"."notification_date_true" = "TBL_RIGHT"."notification_date_true" AND "TBL_LEFT"."address_uid_true" = "TBL_RIGHT"."address_uid_true" AND "TBL_LEFT"."source_true" = "TBL_RIGHT"."source_true" AND "TBL_LEFT"."notification_date_to_validate" = "TBL_RIGHT"."max_date")
) "stvajxdnea") "kejhfymfwt"
GROUP BY "source_to_validate", "censored_age_at_notice"
) "long8427270"
