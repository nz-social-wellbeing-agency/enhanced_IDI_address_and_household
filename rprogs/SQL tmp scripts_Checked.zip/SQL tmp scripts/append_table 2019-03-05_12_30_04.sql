INSERT INTO [IDI_Sandpit].[DL-MAA2016-15].chh_individual_refined("snz_uid", "notification_date", "address_uid", "source", "validation", "concurrent_flag")
  SELECT "snz_uid", "notification_date", "address_uid", "source", "validation", "concurrent_flag"
FROM (SELECT * FROM [IDI_Sandpit].[DL-MAA2016-15].chh_tmp_cautious_6881945512 AS "TBL_LEFT"

WHERE NOT EXISTS (
  SELECT 1 FROM [IDI_Sandpit].[DL-MAA2016-15].chh_tmp_last_unsupported_simultaneous_notifications AS "TBL_RIGHT"
  WHERE ("TBL_LEFT"."snz_uid" = "TBL_RIGHT"."snz_uid" AND "TBL_LEFT"."notification_date" = "TBL_RIGHT"."notification_date" AND "TBL_LEFT"."address_uid" = "TBL_RIGHT"."address_uid" AND "TBL_LEFT"."source" = "TBL_RIGHT"."source")
)) "rmfisawdxq"
